from gendiff.libs.diff_flat import generate_diff

__all__ = ('generate_diff',)
